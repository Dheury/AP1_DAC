package bean;

import javax.faces.application.FacesMessage;

import javax.faces.context.FacesContext;

import dao.VacinaDao;
import entidades.Vacina;

import java.util.List;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class VacinaBean {

    private Vacina vacina = new Vacina();
    private List<Vacina> lista;
    private int quantidade;
        
    public VacinaBean() {
    	lista = VacinaDao.listar(); 
    }
    
    public String salvar() {
        VacinaDao.salvar(vacina);
        vacina = new Vacina();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Contato salvo com sucesso!"));
        return null;
    }

    public Vacina getVacina() {
        return vacina;
    }

    public void setVacina(Vacina vacina) {
        this.vacina = vacina;
    }

    public List<Vacina> getLista() {
        return lista;
    }

    public void setLista(List<Vacina> lista) {
        this.lista = lista;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

   
}

package dao;

import javax.persistence.Query;

import java.util.List;

import javax.persistence.EntityManager;

import entidades.Vacina;
import util.JPAUtil;

public class VacinaDao {

    public static void salvar(Vacina v) {
        EntityManager em = JPAUtil.criarEntityManager();
        em.getTransaction().begin();
        em.persist(v);
        em.getTransaction().commit();
        em.close();
    }

    public static List<Vacina> listar() {
        EntityManager em = JPAUtil.criarEntityManager();
        Query q = em.createQuery("select v from Vacina v");
        List<Vacina> vacina = q.getResultList();
        em.close();
        return vacina;
    }

    public static int contar() {
        List<Vacina> vacina = listar();
        return vacina.size();
    }
}
